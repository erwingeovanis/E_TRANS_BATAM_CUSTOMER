from flask import Flask,request,url_for,jsonify,send_from_directory
import random
import string
import decimal
import flask.json
import hashlib
import datetime 
import os
import pymysql.cursors
from flask_mail import Mail,Message

def random_char(y):
       return ''.join(random.choice(string.ascii_letters) for x in range(y))
class MyJSONEncoder(flask.json.JSONEncoder):
    def default(self, obj):
        print(str(obj))
        if isinstance(obj, decimal.Decimal):
            # Convert decimal instances to strings.
            return str(obj)
        if isinstance(obj, (datetime.date, datetime.datetime,datetime.timedelta)):
            return ""+str(obj)+""
        return super(MyJSONEncoder, self).default(obj)
conn=cursor=None
UPLOAD_FOLDER = 'news-images'
uploadpath=os.path.join(os.getcwd(),UPLOAD_FOLDER)
def openDb():
    global conn,cursor
    conn=pymysql.connect(host="localhost",user="root",password="",database="etrans")
    cursor=conn.cursor(pymysql.cursors.DictCursor)
def closeDb():
    cursor.close()
    conn.close()
app=Flask(__name__)
app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'mailerfrees@gmail.com'
app.config['MAIL_PASSWORD'] = 'freesmailer29'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
app.json_encoder = MyJSONEncoder
mail = Mail(app)
@app.route('/')
def index():
    return "hola"
@app.route('/news')
def getnews():
   openDb()
   container=[]
   cursor.execute("Select * from news")
   data=cursor.fetchall()
   for field in data:
       container.append(field)
   closeDb()
   return jsonify(container)
@app.route('/jurusan')
def getJurusan():
   openDb()
   container=[]
   cursor.execute("Select * from jurusan")
   data=cursor.fetchall()
   
   for field in data:
       daftarhalte=field['rute'].split(",")
       field['rute']=[]
       id_jurusan=field['id_jurusan']
       field['jadwal']=[]
       cursor.execute("select waktu from jadwal where id_jurusan=%s",id_jurusan)
       datajadwal=cursor.fetchall()
       for jadwal in datajadwal:
           field['jadwal'].append(jadwal['waktu'])
       for idhalte in daftarhalte:
           cursor.execute("Select * from halte where id_halte='"+idhalte+"'")
           field['rute'].append(cursor.fetchone())
       container.append(field)
   closeDb()
   return jsonify(container)
@app.route('/halte')
def getHalte():
   openDb()
   container=[]
   cursor.execute("Select * from halte")
   data=cursor.fetchall()
   for field in data:
       container.append(field)
   closeDb()
   return jsonify(container)
# @app.route('/profile/<id>/book')
# def getBookList(id):
#    openDb()
#    container=[]
#    cursor.execute("Select * from booking natural join product where id_user=%s",(id))
#    data=cursor.fetchall()
#    for order in data:
#     #    order.pop("description",None)
#     #    order.pop("location",None)
#     #    order.pop("pictures",None)
#     #    order.pop("count_field",None)
#     #    order.pop("price",None)
#        container.append(order)
#    closeDb()
#    return jsonify(container)
@app.route('/auth/login', methods=['POST'])
def login():
   map=request.form
   password=hashlib.sha1(map['password'].encode()).hexdigest()
   sql="select count(*) as result,email,id_user as uid from user where email=%s AND password=%s"
   val=(map['email'],password)
   print("select count(*) as result,email,id_user as uid from user where email="+val[0]+" AND password="+val[1])
   openDb()
   cursor.execute(sql,val)
   result = cursor.fetchone()
   
   result['message']="Login Success" if result['result']>0 else "login not success"
   if(result['result']>0):
       result['data']={
           "email":result['email'],
           "uid":result['uid'],
       }
   result['result']=result['result']>0
   closeDb()
   return result

@app.route('/auth/register', methods=['POST'])
def register():
   map=request.form
   sql="select count(*) as result from user where email=%s"
   val=(map['email'])

   openDb()
   cursor.execute(sql,val)
   result=cursor.fetchone()
   if (result['result']>0):
       closeDb()
       result['message']="email has been used"
       result['result']=False
       return jsonify(result)
   else:
       password=hashlib.sha1(map['password'].encode()).hexdigest()
       sql="INSERT INTO `user`"
       sql+="(`email`, `password`,`name`)"
       sql+=" VALUES (%s,%s,%s)"
       val=(map['email'],password,map['name'])
       try:
            cursor.execute(sql,val)
            conn.commit()
            sql="select count(email) as result,email,id_user as uid from user where email=%s AND password=%s"
            val=(map['email'],password)
            cursor.execute(sql,val)
            results={

            }
            result = cursor.fetchone()
            if(result['result']==1):
                    results['data']={
                        "email":result['email'],
                        "uid":result['uid'],
                    } 
            closeDb()
            results['result']=True
            results['message']="register success"
            return jsonify(results)
       except Exception:
            results={
            }
            closeDb()
            results['result']=True
            results['message']="register success"
            return jsonify(results)

@app.route('/profile/<id>/details')
def getProfile(id):
   sql="SELECT * FROM `user` WHERE id_user=%s"
   openDb()
   cursor.execute(sql,(id))
   data=cursor.fetchone()
   data['password']="*******"
   closeDb()
   if data==None:
       return jsonify({})
   return jsonify(data)
@app.route('/profile/<id>/change-password', methods=['POST'])
def cpassword(id):
   map=request.form
   password=hashlib.sha1(map['password'].encode()).hexdigest()
   sql="UPDATE `user` SET `password` = %s WHERE `user`.`id_user` = %s;"
   openDb()
   result={
       
   }
   try:
       cursor.execute(sql,(password,id))
       conn.commit()
       result['result']=True
       result['message']="change password success"
       closeDb()
       return jsonify(result)
   except Exception:
       closeDb()
       result={
       "result":False,
       "message":"cannot change you\'re password"}
       return jsonify(result)

   
@app.route('/news/image/<filename>')
def geturlfile(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)
@app.route('/profile/<email>/reset', methods=['POST'])
def reset(email):
   map=request.form
   sql="select count(*) as result,id_user as uid from user where email=%s"
   val=(map['email'])
   openDb()
   cursor.execute(sql,val)
   result=cursor.fetchone()
   if (result['result']<1):
       result['message']="your email is not registered"
       result['result']=False
       closeDb()
       return jsonify(result)
   else:
       result['result']=True
       result['message']="your verification has sent, please check your email!"
       code=random_char(6)
       result["data"]={
           "uid":result["uid"],
          "code":code
        }
       msgmail = Message('Verification code', sender = 'mailerfrees@gmail.com', recipients = [email])
       msgmail.body = "hey this your verification code : "+code
       mail.send(msgmail)
       closeDb()
       return jsonify(result)
if __name__=="__main__":
    app.run(debug=True,host="192.168.43.150",port="80")

